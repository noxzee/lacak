package config

const unknown = "unknown"

// Version is the corresponding release tag
var Version = unknown

// Commit is the corresponding Git commit
var Commit = unknown
