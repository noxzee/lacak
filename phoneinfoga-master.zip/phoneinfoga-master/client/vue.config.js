module.exports = {
  publicPath: "/",
};
